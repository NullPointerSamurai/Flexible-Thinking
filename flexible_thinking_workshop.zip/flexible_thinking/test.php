<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Guess the Number Game</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
    }
    #guess-input {
      padding: 8px;
      margin: 10px;
      width: 50px;
      text-align: center;
    }
    #output {
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <h1>Guess the Number Game</h1>
  <p>Guess a number between 1 and 100:</p>
  <input type="number" id="guess-input" min="1" max="100">
  <button onclick="checkGuess()">Guess!</button>
  <div id="output"></div>

  <script src="game.js"></script>
</body>
</html>

<script>

    // Generate a random number between 1 and 100
let secretNumber = Math.floor(Math.random() * 100) + 1;
console.log("Secret number:", secretNumber);

let attempts = 0;

function checkGuess() {
  let guess = parseInt(document.getElementById('guess-input').value);
  
  if (isNaN(guess) || guess < 1 || guess > 100) {
    document.getElementById('output').innerHTML = "Please enter a valid number between 1 and 100.";
    return;
  }
  
  attempts++;
  
  if (guess === secretNumber) {
    document.getElementById('output').innerHTML = `Congratulations! You guessed the number ${secretNumber} in ${attempts} attempts.`;
  } else if (guess < secretNumber) {
    document.getElementById('output').innerHTML = "Too low! Try a higher number.";
  } else {
    document.getElementById('output').innerHTML = "Too high! Try a lower number.";
  }
}

</script>