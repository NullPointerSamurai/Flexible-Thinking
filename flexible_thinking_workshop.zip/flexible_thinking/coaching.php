<!DOCTYPE html>
<html lang="en">

<?php include "includes/head.php"; ?>

<body class="coaching-page">

  <?php include "includes/header.php"; ?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title" data-aos="fade">
      <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>Coaching</h1>
            </div>
          </div>
        </div>
      </div>
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.html">Home</a></li>
            <li class="current">coaching</li>
          </ol>
        </div>
      </nav>
    </div><!-- End Page Title -->

    <!-- Coaching Section -->
    <section id="coaching" class="coaching section">
      <div class="container" data-aos="fade-up">

        <div class="row mb-4">
          <div class="col-md-4 d-flex align-items-stretch">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/about.jpg" alt="Καθοδήγηση Ομάδων" style="max-width: 420px;">
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="">Personalized Feedback</a></h5>
                <p class="card-text">Provide specific, constructive feedback aimed at improving their understanding and skills related to internet safety.</p>
              </div>
            </div>
          </div>
     
        </div>

        </div>
      </div> <!-- /coaching container -->

      <style>
        body {
          background-color: #f0f8ff;
        }

        .quiz {
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
          padding: 20px;
        }

        .quiz h3 {
          background-color: #007bff;
          color: #ffffff;
          padding: 10px;
          border-radius: 5px;
          text-align: center;
        }

        .question {
          margin-bottom: 20px;
        }

        .question label {
          font-weight: bold;
        }

        .question div {
          background-color: #e9ecef;
          border-radius: 5px;
          padding: 10px;
        }

        .correct {
          background-color: #d4edda;
        }

        .incorrect {
          background-color: #f8d7da;
        }

        #result {
          background-color: #ffc107;
          padding: 10px;
          border-radius: 5px;
          text-align: center;
          font-weight: bold;
        }
      </style>

      <div class="container mt-5">
        <div class="quiz">
          <h3>Programming Knowledge Quiz</h3>
          <form id="quizForm">
            <div class="form-group question">
              <label>1. What is an algorithm?</label>
              <div>
                <input type="radio" name="q1" value="a"> A sequence of steps to solve a problem<br>
                <input type="radio" name="q1" value="b"> A type of programming language<br>
                <input type="radio" name="q1" value="c"> A hardware component<br>
              </div>
            </div>
            <div class="form-group question">
              <label>2. What is Scratch?</label>
              <div>
                <input type="radio" name="q2" value="a"> A text editor<br>
                <input type="radio" name="q2" value="b"> A visual programming environment<br>
                <input type="radio" name="q2" value="c"> An operating system<br>
              </div>
            </div>
            <div class="form-group question">
              <label>3. What is the purpose of debugging?</label>
              <div>
                <input type="radio" name="q3" value="a"> To write code<br>
                <input type="radio" name="q3" value="b"> To find and fix errors in code<br>
                <input type="radio" name="q3" value="c"> To execute code<br>
              </div>
            </div>
            <div class="form-group question">
              <label>4. What is a variable in programming?</label>
              <div>
                <input type="radio" name="q4" value="a"> A fixed value<br>
                <input type="radio" name="q4" value="b"> A value that can change<br>
                <input type="radio" name="q4" value="c"> A type of function<br>
              </div>
            </div>
            <div class="form-group question">
              <label>5. What does a loop do in programming?</label>
              <div>
                <input type="radio" name="q5" value="a"> Executes code repeatedly<br>
                <input type="radio" name="q5" value="b"> Stops the execution of code<br>
                <input type="radio" name="q5" value="c"> Defines a variable<br>
              </div>
            </div>
            <div class="form-group question">
              <label>6. What is a database?</label>
              <div>
                <input type="radio" name="q6" value="a"> A collection of data<br>
                <input type="radio" name="q6" value="b"> A type of loop<br>
                <input type="radio" name="q6" value="c"> A software bug<br>
              </div>
            </div>
            <button type="button" class="btn btn-primary btn-block" onclick="checkAnswers()">Submit</button>
          </form>
          <div id="result" class="mt-3"></div>
        </div>
      </div>

      <script>
        function checkAnswers() {
          const answers = {
            q1: 'a',
            q2: 'b',
            q3: 'b',
            q4: 'b',
            q5: 'a',
            q6: 'a'
          };

          let score = 0;
          const form = document.getElementById('quizForm');
          const resultDiv = document.getElementById('result');
          resultDiv.innerHTML = '';

          for (let [question, correctAnswer] of Object.entries(answers)) {
            const userAnswer = form[question].value;
            const questionDiv = form[question][0].parentElement;

            if (userAnswer === correctAnswer) {
              score++;
              questionDiv.classList.add('correct');
              questionDiv.classList.remove('incorrect');
            } else {
              questionDiv.classList.add('incorrect');
              questionDiv.classList.remove('correct');
            }
          }

          resultDiv.innerHTML = `<h4>Your score: ${score} / ${Object.keys(answers).length}</h4>`;
        }
      </script>

    </section><!-- /coaching Section -->

  </main>

  <?php include "includes/footer.php"; ?>


</body>

</html>