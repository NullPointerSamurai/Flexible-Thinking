<!DOCTYPE html>
<html lang="en">

<?php include "includes/head.php"; ?>

<body class="modeling-page">

  <?php include "includes/header.php"; ?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title bg-primary text-white py-5" data-aos="fade">
      <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>Modeling</h1>
            </div>
          </div>
        </div>
      </div>
      <nav class="breadcrumbs">
        <div class="container">
          <ol class="breadcrumb bg-primary text-white">
            <li class="breadcrumb-item"><a href="index.html" class="text-white">Home</a></li>
            <li class="breadcrumb-item active">Modeling</li>
          </ol>
        </div>
      </nav>
    </div><!-- End Page Title -->

    <!-- Modeling Section -->
    <section id="modeling" class="modeling section py-5">
      <div class="container" data-aos="fade-up">
        <h1 class="my-4">Approach to Cognitive Apprenticeship (CA)</h1>
        <div class="content-section">
          <h2>1. Modeling</h2>
          <p>At this stage, the instructor demonstrates the skills or processes that learners need to acquire. The goal is for learners to see how something is done and understand the steps involved.</p>

          <h3>Strategies:</h3>
          <ul class="list-group mb-4">
            <li class="list-group-item">Use of live demonstrations.</li>
            <li class="list-group-item">Provide videos or multimedia showing the process.</li>
            <li class="list-group-item">Use explanatory slides or diagrams.</li>
          </ul>

          <h3>Microscript Example:</h3>
          <p class="border rounded p-3 bg-light">"Watch the video demonstrating how to solve a mathematical equation. Pay attention to the steps and strategies used by the teacher."</p>

          <!-- Example Video -->
          <div class="embed-responsive embed-responsive-16by9 mb-4">
            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/example" allowfullscreen></iframe>
          </div>
        </div>

        <!-- Interactive Content Section -->
        <div class="content-section">
          <h2>Interactive Content</h2>

          <!-- Quiz Example 1 -->
          <h3>Quiz 1</h3>
          <div id="quiz1" class="mb-4">
            <p>What are the basic steps to solve a mathematical equation?</p>
            <form>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="quizOptions1" id="option1-1" value="option1">
                <label class="form-check-label" for="option1-1">Understanding the problem</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="quizOptions1" id="option1-2" value="option2">
                <label class="form-check-label" for="option1-2">Applying solution strategies</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="quizOptions1" id="option1-3" value="option3">
                <label class="form-check-label" for="option1-3">Checking the result</label>
              </div>
            </form>
            <button class="btn btn-primary mt-2" onclick="checkQuiz(1)">Submit</button>
            <p id="quizResult1" class="mt-2"></p>
          </div>

          <!-- Quiz Example 2 -->
          <h3>Quiz 2</h3>
          <div id="quiz2" class="mb-4">
            <p>What is the first step in the modeling process?</p>
            <form>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="quizOptions2" id="option2-1" value="option1">
                <label class="form-check-label" for="option2-1">Identifying the problem</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="quizOptions2" id="option2-2" value="option2">
                <label class="form-check-label" for="option2-2">Understanding the process</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="quizOptions2" id="option2-3" value="option3">
                <label class="form-check-label" for="option2-3">Observing the process</label>
              </div>
            </form>
            <button class="btn btn-primary mt-2" onclick="checkQuiz(2)">Submit</button>
            <p id="quizResult2" class="mt-2"></p>
          </div>

          <!-- Quiz Example 3 -->
          <h3>Quiz 3</h3>
          <div id="quiz3" class="mb-4">
            <p>What is the final step in the modeling process?</p>
            <form>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="quizOptions3" id="option3-1" value="option1">
                <label class="form-check-label" for="option3-1">Understanding the process</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="quizOptions3" id="option3-2" value="option2">
                <label class="form-check-label" for="option3-2">Applying solution strategies</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="quizOptions3" id="option3-3" value="option3">
                <label class="form-check-label" for="option3-3">Reflecting on the process</label>
              </div>
            </form>
            <button class="btn btn-primary mt-2" onclick="checkQuiz(3)">Submit</button>
            <p id="quizResult3" class="mt-2"></p>
          </div>

          <!-- Quiz Example 4 -->
          <h3>Quiz 4</h3>
          <div id="quiz4" class="mb-4">
            <p>What is a key strategy used in Cognitive Apprenticeship?</p>
            <form>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="quizOptions4" id="option4-1" value="option1">
                <label class="form-check-label" for="option4-1">Memorization techniques</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="quizOptions4" id="option4-2" value="option2">
                <label class="form-check-label" for="option4-2">Modeling</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="quizOptions4" id="option4-3" value="option3">
                <label class="form-check-label" for="option4-3">Copying answers from others</label>
              </div>
            </form>
            <button class="btn btn-primary mt-2" onclick="checkQuiz(4)">Submit</button>
            <p id="quizResult4" class="mt-2"></p>
          </div>

        </div>
      </div>

      <!-- Custom JS for interactive content -->
      <script>
        function checkQuiz(quizNumber) {
          const selectedOption = document.querySelector('input[name="quizOptions' + quizNumber + '"]:checked');
          const resultElement = document.getElementById('quizResult' + quizNumber);
          if (selectedOption) {
            if ((quizNumber === 1 && selectedOption.value === 'option2') || (quizNumber === 2 && selectedOption.value === 'option3') || (quizNumber === 3 && selectedOption.value === 'option3') || (quizNumber === 4 && selectedOption.value === 'option2')) {
              resultElement.textContent = 'Correct! Your answer is correct.';
              resultElement.className = 'text-success';
            } else {
              resultElement.textContent = 'Wrong. Try again.';
              resultElement.className = 'text-danger';
            }
          } else {
            resultElement.textContent = 'Please select an answer.';
            resultElement.className = 'text-warning';
          }
        }
      </script>

    </section><!-- /modeling Section -->

  </main>

  <?php include "includes/footer.php"; ?>
</body>

</html>
