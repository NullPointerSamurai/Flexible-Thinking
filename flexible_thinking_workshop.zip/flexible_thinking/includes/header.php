<header id="header" class="header d-flex align-items-center sticky-top">
  <div class="container-fluid container-xl position-relative d-flex align-items-center">

    <a href="index.php" class="logo d-flex align-items-center me-auto">
      <!-- Uncomment the line below if you also wish to use an image logo -->
      <!-- <img src="assets/img/logo.png" alt=""> -->
      <h1 class="sitename">SecureNet Insights</h1>
    </a>

    <nav id="navmenu" class="navmenu">
      <ul>
        <li><a href="index.php">Home<br></a></li>

        <li class="dropdown"><a href="#"><span>Cognitive Apprenticeship (CA)</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
          <ul>
            <li><a href="modeling.php">Modeling</a></li>
            <li><a href="coaching.php">Coaching</a></li>
            <li><a href="scaffolding.php">Scaffolding</a></li>
            <li><a href="#">Articulation</a></li>
            <li><a href="#">Reflection</a></li>
            <li><a href="#">Exploration</a></li>
          </ul>
        </li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
      <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
    </nav>

    <a class="btn-getstarted" href="courses.php">Get Started</a>

  </div>
</header>